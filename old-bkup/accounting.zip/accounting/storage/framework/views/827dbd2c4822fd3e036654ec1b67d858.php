<?php if (isset($component)) { $__componentOriginal3b14fcd8a6c39b7cf7f023f019819af4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b14fcd8a6c39b7cf7f023f019819af4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.adminheader','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('adminheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b14fcd8a6c39b7cf7f023f019819af4)): ?>
<?php $attributes = $__attributesOriginal3b14fcd8a6c39b7cf7f023f019819af4; ?>
<?php unset($__attributesOriginal3b14fcd8a6c39b7cf7f023f019819af4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b14fcd8a6c39b7cf7f023f019819af4)): ?>
<?php $component = $__componentOriginal3b14fcd8a6c39b7cf7f023f019819af4; ?>
<?php unset($__componentOriginal3b14fcd8a6c39b7cf7f023f019819af4); ?>
<?php endif; ?>
      <section class="table-components">
        <div class="container-fluid">
          <!-- ========== title-wrapper start ========== -->
          <div class="title-wrapper pt-30">
            <div class="row align-items-center">
              <div class="col-md-6">
                <div class="title">
                  <h2>Tables</h2>
                </div>
              </div>
              <!-- end col -->
              <div class="col-md-6">
                <div class="breadcrumb-wrapper">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a href="#0">Dashboard</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Tables
                      </li>
                    </ol>
                  </nav>
                </div>
              </div>
              <!-- end col -->
            </div>
            <!-- end row -->
          </div>
          <!-- ========== title-wrapper end ========== -->

          <!-- ========== tables-wrapper start datatable ========== -->
          <div class="tables-wrapper">
            <div class="row">
              <div class="col-lg-12">
                
                <div class="card-style mb-30">
                  <div class="d-flex align-items-center w-100 justify-content-between">
                      <div class="ledt-divtyu">
                        <h6 class="mb-10">User list</h6>
                        <p class="text-sm mb-20">
                          For basic styling—light padding and only horizontal
                          dividers—use the class table.
                        </p>
                      </div>
                      <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"> Create </button>
                  </div>
                 
                    <table id="example" class="table-wrapper table table-striped nowrap" style="width:100%">
                      <thead>
                        <tr>
                          <th class="lead-info">
                            <h6>Name</h6>
                          </th>
                          <th class="lead-email">
                            <h6>Email</h6>
                          </th>
                          <th class="lead-phone">
                            <h6>Role</h6>
                          </th>
                          <th class="lead-company">
                            <h6>Warehouse</h6>
                          </th>
                          <th>
                            <h6>Action</h6>
                          </th>
                        </tr>
                        <!-- end table row-->
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td class="min-width">
                            <div class="lead">
                             
                              <div class="lead-text">
                                <p><?php echo e($user->name); ?></p>
                              </div>
                            </div>
                          </td>
                          <td class="min-width">
                            <p><a href="#0"><?php echo e($user->email); ?></a></p>
                          </td>
                          <td class="min-width">
                            <p><?php echo e($user->role); ?></p>
                          </td>
                          <td class="min-width">
                            <p><?php echo e($user->warehouse); ?></p>
                          </td>
                          <td>
                            <div class="action">
                             <a href="<?php echo e(URL::to('deleteuser', $user->id)); ?>" class="text-danger"  onclick="return confirm('Are you sure you want to delete this User?')">
                                <i class="lni lni-trash-can"></i>
                            </a>
                            </div>
                          </td>
                        </tr>
                    
                 
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    <!-- end table -->
                 
                </div>
                <!-- end card -->
              </div>
              <!-- end col -->
            </div>
            <!-- end row -->

            
            <!-- end row -->
          </div>
          <!-- ========== tables-wrapper end ========== -->
        </div>
        <!-- end container -->
      </section>
      <!-- ========== table components end ========== -->
      <?php if (isset($component)) { $__componentOriginalf0dcd268983af79675e70ceb58441f70 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf0dcd268983af79675e70ceb58441f70 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.adminfooter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('adminfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf0dcd268983af79675e70ceb58441f70)): ?>
<?php $attributes = $__attributesOriginalf0dcd268983af79675e70ceb58441f70; ?>
<?php unset($__attributesOriginalf0dcd268983af79675e70ceb58441f70); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf0dcd268983af79675e70ceb58441f70)): ?>
<?php $component = $__componentOriginalf0dcd268983af79675e70ceb58441f70; ?>
<?php unset($__componentOriginalf0dcd268983af79675e70ceb58441f70); ?>
<?php endif; ?>
      
    </main>
    

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add New Record</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo e(URL::to('/add-record')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
            <div class="row gy-4">
                <div class="col-lg-6">
                <input type="text" class="form-control" name="name" placeholder="First Name" required />
                </div>
                <div class="col-lg-6">
                <input type="email" class="form-control" name="email" placeholder="Email" required />
                </div>
                <div class="col-lg-6">
                <input type="password" class="form-control" name="password" placeholder="Password" required />
                </div>
                
                <div class="col-lg-6">
                <select class="form-control" name="role_id" required>
                    <option value="" disabled selected>Choose Role</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                </div>
                <div class="col-lg-6">
                <select class="form-control" name="status" required>
                    <option value="" disabled selected>Choose Status</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
                </div>
                <div class="col-lg-6">
                <input class="form-control" type="file" name="profile_image" id="formFile" />
                </div>
                <div class="col-lg-4">
                <p>Access warehouses</p>
                <select class="form-control" name="warehouse">
                    <option value="" disabled selected>Choose Warehouse</option>
                    <option value="Warehouse 1">Warehouse 1</option>
                    <option value="Warehouse 2">Warehouse 2</option>
                    <option value="Warehouse 3">Warehouse 3</option>
                </select>
                </div>
            </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
        </div>
    </div>
    </div>


    <?php /**PATH C:\xampp\htdocs\accounting\resources\views/user.blade.php ENDPATH**/ ?>