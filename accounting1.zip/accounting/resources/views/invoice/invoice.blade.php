<div id="in_pos">
    <div class="hidden-print">
        <a class="btn btn-primary"> Print</a> <br>
    </div> 
    <div id="invoice-POS">
        <div>
            <div class="info">
                <h2 class="text-center">Posly</h2>
                 <p dir="ltr"><span>Date : 27-04-2025 12:56 <br></span> <span>Sale: SO-20230616-034724 <br></span> <span>Address : 3618 Abia Martin Drive
                    <br></span> <span>Email : admin@example.com <br></span> <span>Phone : 6315996770
                    <br></span> <span>Customer : Fred C. Rasmussen
                    <br></span> <span>Warehouse : Warehouse 2
                    <br></span>
               </p>
            </div> 
            <table class="detail_invoice"><tbody><tr><td colspan="3">
                Pomme
                <br style="display: none;"> <span style="display: none;">IMEI_SN :
                  </span> <br> <span>4.00 kg x
                  $ 25.00</span></td> <td class="product_detail_invoice">
                $ 100.00
              </td></tr><tr><td colspan="3">
                earphones
                <br style="display: none;"> <span style="display: none;">IMEI_SN :
                  </span> <br> <span>5.00 pc x
                  $ 36.00</span></td> <td class="product_detail_invoice">
                $ 180.00
              </td></tr> <tr class="mt-10"><td colspan="3" class="total">Tax</td> <td class="total text-right">
                $ 0.00 (0.00 %)
              </td></tr> <tr class="mt-10"><td colspan="3" class="total">Discount</td> <td class="total text-right"><span>$ 0.00</span></td></tr> <tr class="mt-10"><td colspan="3" class="total">Shipping</td> <td class="total text-right">
                $ 0.00</td></tr> <tr class="mt-10"><td colspan="3" class="total">Grand Total</td> <td class="total text-right">
                $ 280.00</td></tr> <tr><td colspan="3" class="total">Paid</td> <td class="total text-right">
                 $ 280.00</td></tr> <tr><td colspan="3" class="total">Due</td> <td class="total text-right">
                $ 0.00
              </td></tr></tbody>
            </table> 
            <table class="change mt-3"><thead><tr><th colspan="1" class="text-left">Paid by:</th> <th colspan="2" class="text-right">Amount:</th></tr></thead> <tbody><tr><td colspan="1" class="text-left">Credit card</td> <td colspan="2" class="text-right">$ 280.00
              </td></tr></tbody>
            </table> 
            <div id="legalcopy" class="ms-2"><p class="legal"><strong>Thank You For Shopping With Us Please Come Again</strong></p>
        </div>
    </div>
</div>
</div>